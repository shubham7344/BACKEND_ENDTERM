package com.UserAplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserAplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserAplicationApplication.class, args);
	}

}
